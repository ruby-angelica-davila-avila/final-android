package com.mycompany.ulllproyectofinalandroid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
