// Export pages
export 'iniciasesion/iniciasesion_widget.dart' show IniciasesionWidget;
export 'resistrate/resistrate_widget.dart' show ResistrateWidget;
export 'avisodeprivacidad/avisodeprivacidad_widget.dart'
    show AvisodeprivacidadWidget;
export 'cybertruck/cybertruck_widget.dart' show CybertruckWidget;
export 'powerwall/powerwall_widget.dart' show PowerwallWidget;
export 'inicio/inicio_widget.dart' show InicioWidget;
export 'modely/modely_widget.dart' show ModelyWidget;
export 'modelx/modelx_widget.dart' show ModelxWidget;
export 'inventario/inventario_widget.dart' show InventarioWidget;
export 'misdatos/misdatos_widget.dart' show MisdatosWidget;
export 'conclusiones/conclusiones_widget.dart' show ConclusionesWidget;
export 'empleados/empleados_widget.dart' show EmpleadosWidget;
export 'registro/registro_widget.dart' show RegistroWidget;
export 'personaliza/personaliza_widget.dart' show PersonalizaWidget;
export 'powerwall_copy/powerwall_copy_widget.dart' show PowerwallCopyWidget;
